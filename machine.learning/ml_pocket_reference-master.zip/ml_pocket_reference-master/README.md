# Welcome

Here you will find the source code for the book [*Machine Learning Pocket Reference*]( https://learning.oreilly.com/library/view/machine-learning-pocket/9781492047537/)

## Code Examples

Every chapter has a notebook with the code from that notebook.

## Thanks!

Thanks to readers for their support. If you enjoyed the book, please consider leaving a review on Amazon, or sharing it on social media.

## Comments?

If you have comments or issues with the book, please consider filing an issue. The digital version may recieve updates. Big updates could be addressed in future versions of the book.

Thanks again! [Matt Harrison](https://twitter.com/__mharrison__)
